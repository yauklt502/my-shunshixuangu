@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo  ======================================
echo   这是【顺势选股】  http://127.0.0.1:8787/
echo   Sequoia-X 请用另一个文件夹，地址 9801
echo  ======================================
echo.
echo  先清掉占用 8787 的旧进程...
powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 8787 -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }"
for /f "tokens=5" %%p in ('netstat -aon ^| findstr ":8787" ^| findstr LISTENING') do taskkill /F /PID %%p >nul 2>&1
echo.
where python >nul 2>&1
if %errorlevel%==0 set PY=python
if not defined PY (
  where py >nul 2>&1
  if %errorlevel%==0 set PY=py -3
)
if not defined PY (
  echo 未找到 Python 3。请先安装 https://www.python.org/downloads/ 并勾选 Add python.exe to PATH
  pause
  goto :eof
)
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://127.0.0.1:8787/"
%PY% serve_web.py
if errorlevel 1 pause
