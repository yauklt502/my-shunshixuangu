@echo off
cd /d "%~dp0"
call "%~dp0CHECK.bat"
