@echo off
setlocal
cd /d "%~dp0"
title KaiPanLa

where node >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Please install Node.js 18+ first.
  echo https://nodejs.org/
  start https://nodejs.org/
  pause
  exit /b 1
)

if not exist "node_modules\" (
  echo Installing express...
  call npm install --omit=dev
  if errorlevel 1 (
    echo npm install failed. Check your network.
    pause
    exit /b 1
  )
)

where python >nul 2>&1
if not errorlevel 1 (
  if not exist "%LOCALAPPDATA%\kaipanla-tdx.flag" (
    echo Installing eltdx for stock charts...
    python -m pip install -r requirements-tdx.txt
    if not errorlevel 1 (
      echo ok> "%LOCALAPPDATA%\kaipanla-tdx.flag"
    )
  )
  start "KaiPanLa-TDX" /min cmd /c "python -m eltdx.http_server --host 127.0.0.1 --port 8790 --tdx-host 115.238.90.165:7709 --log-level warning"
) else (
  echo [WARN] Python not found. Auction list works, but stock 分时/日K charts need Python + eltdx.
)

set NODE_ENV=production
set PORT=3000
set HOST=127.0.0.1
set TDX_HTTP_URL=http://127.0.0.1:8790
echo.
echo KaiPanLa: http://127.0.0.1:3000
echo Close this window to stop.
echo.
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://127.0.0.1:3000"
node server\index.mjs
if errorlevel 1 pause
