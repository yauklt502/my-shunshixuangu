@echo off
chcp 65001 >nul
cd /d "%~dp0"
title 顺势竞价选股

echo.
echo  ========================================
echo   顺势竞价 · 本机选股软件
echo   浏览器将打开 http://127.0.0.1:8787/
echo  ========================================
echo.

where python >nul 2>&1
if %errorlevel%==0 (
  set "PY=python"
  goto :havepy
)
where py >nul 2>&1
if %errorlevel%==0 (
  set "PY=py -3"
  goto :havepy
)

echo [错误] 未找到 Python 3
echo 请先安装: https://www.python.org/downloads/
echo 安装时务必勾选 Add python.exe to PATH
start https://www.python.org/downloads/
pause
exit /b 1

:havepy
if not exist ".venv\Scripts\python.exe" (
  echo 正在创建虚拟环境 .venv ...
  %PY% -m venv .venv
  if errorlevel 1 (
    echo 创建虚拟环境失败
    pause
    exit /b 1
  )
)

set "VPY=.venv\Scripts\python.exe"
set "VPIP=.venv\Scripts\pip.exe"

echo 检查依赖...
"%VPY%" -c "import urllib.request" >nul 2>&1
"%VPIP%" install -q -r requirements.txt
if errorlevel 1 (
  echo 依赖安装失败，请检查网络后重试
  pause
  exit /b 1
)

echo.
echo 启动中... 关闭本窗口即停止服务
echo.
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://127.0.0.1:8787/"
"%VPY%" -m app --no-open --host 127.0.0.1 --port 8787
pause
