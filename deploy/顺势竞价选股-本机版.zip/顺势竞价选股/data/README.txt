可选：运行 scripts/download_backtest_data.py 下载回测行情。
选股软件本身不依赖此目录。
