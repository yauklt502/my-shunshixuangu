@echo off
chcp 65001 >nul
echo 正在结束占用 8787 端口的进程...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :8787 ^| findstr LISTENING') do (
  taskkill /F /PID %%a >nul 2>&1
)
echo 完成
pause
