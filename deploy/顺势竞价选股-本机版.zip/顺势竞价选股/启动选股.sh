#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo "顺势竞价 · http://127.0.0.1:8787/"
if [[ ! -d .venv ]]; then
  python3 -m venv .venv
fi
# shellcheck disable=SC1091
source .venv/bin/activate
pip install -q -r requirements.txt
(sleep 1; command -v xdg-open >/dev/null && xdg-open http://127.0.0.1:8787/ || true) &
python -m app --no-open --host 127.0.0.1 --port 8787
